package com.alojamientos.modelo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Reserva {
    public enum Estado { ACTIVA, CANCELADA }

    private final String codigo;
    private final Cliente cliente;
    private final Alojamiento alojamiento;
    private final LocalDate fechaIngreso;
    private final LocalDate fechaSalida;
    private final int cantidadHuespedes;
    private Estado estado;

    public Reserva(String codigo, Cliente cliente, Alojamiento alojamiento, LocalDate fechaIngreso,
                   LocalDate fechaSalida, int cantidadHuespedes) {
        if (codigo == null || codigo.isBlank()) throw new IllegalArgumentException("El código de reserva es obligatorio.");
        if (cliente == null || alojamiento == null) throw new IllegalArgumentException("El cliente y el alojamiento son obligatorios.");
        if (fechaIngreso == null || fechaSalida == null || !fechaSalida.isAfter(fechaIngreso))
            throw new IllegalArgumentException("La fecha de salida debe ser posterior al ingreso.");
        if (cantidadHuespedes <= 0 || cantidadHuespedes > alojamiento.getCapacidad())
            throw new IllegalArgumentException("La cantidad de huéspedes debe estar entre 1 y la capacidad del alojamiento.");
        this.codigo = codigo.trim();
        this.cliente = cliente;
        this.alojamiento = alojamiento;
        this.fechaIngreso = fechaIngreso;
        this.fechaSalida = fechaSalida;
        this.cantidadHuespedes = cantidadHuespedes;
        this.estado = Estado.ACTIVA;
    }

    public String getCodigo() { return codigo; }
    public Cliente getCliente() { return cliente; }
    public Alojamiento getAlojamiento() { return alojamiento; }
    public LocalDate getFechaIngreso() { return fechaIngreso; }
    public LocalDate getFechaSalida() { return fechaSalida; }
    public int getCantidadHuespedes() { return cantidadHuespedes; }
    public Estado getEstado() { return estado; }
    public void cancelar() {
        if (estado == Estado.CANCELADA) throw new IllegalStateException("La reserva ya está cancelada.");
        estado = Estado.CANCELADA;
    }

    public boolean seSuperpone(LocalDate ingreso, LocalDate salida) {
        return fechaIngreso.isBefore(salida) && ingreso.isBefore(fechaSalida);
    }

    @Override
    public String toString() {
        return String.format("%s | %s%n  Cliente: %s | Alojamiento: %s%n  Fechas: %s a %s | Huéspedes: %d",
                codigo, estado, cliente.getNombre(), alojamiento.getCodigo(),
                fechaIngreso.format(DateTimeFormatter.ofPattern("dd/MM/uuuu")),
                fechaSalida.format(DateTimeFormatter.ofPattern("dd/MM/uuuu")),
                cantidadHuespedes);
    }
}
