package com.alojamientos.modelo;

public class Cabaña extends Alojamiento {
    private final double cargoLimpieza;

    public Cabaña(String codigo, String nombre, int capacidad, double precioPorNoche, double cargoLimpieza) {
        super(codigo, nombre, "Cabaña", capacidad, precioPorNoche);
        if (!Double.isFinite(cargoLimpieza) || cargoLimpieza < 0)
            throw new IllegalArgumentException("El cargo de limpieza no puede ser negativo.");
        this.cargoLimpieza = cargoLimpieza;
    }

    @Override
    public double calcularEstadia(long noches) {
        Habitacion.validarNoches(noches);
        return getPrecioPorNoche() * noches + cargoLimpieza;
    }

    public double getCargoLimpieza() { return cargoLimpieza; }
    @Override
    public String toString() { return super.toString() + String.format("%n  Cargo de limpieza: $%.2f", cargoLimpieza); }
}
