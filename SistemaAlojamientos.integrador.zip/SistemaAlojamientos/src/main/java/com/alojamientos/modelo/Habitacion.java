package com.alojamientos.modelo;

public class Habitacion extends Alojamiento {
    public Habitacion(String codigo, String nombre, int capacidad, double precioPorNoche) {
        super(codigo, nombre, "Habitación", capacidad, precioPorNoche);
    }

    @Override
    public double calcularEstadia(long noches) {
        validarNoches(noches);
        return getPrecioPorNoche() * noches;
    }

    static void validarNoches(long noches) {
        if (noches <= 0) throw new IllegalArgumentException("La cantidad de noches debe ser mayor que cero.");
    }
}
