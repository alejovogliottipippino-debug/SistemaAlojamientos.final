package com.alojamientos.modelo;

public class Cliente {
    private final String identificacion;
    private String nombre;
    private String telefono;

    public Cliente(String identificacion, String nombre, String telefono) {
        this.identificacion = requerido(identificacion, "La identificación");
        this.nombre = requerido(nombre, "El nombre");
        this.telefono = requerido(telefono, "El teléfono");
    }

    public String getIdentificacion() { return identificacion; }
    public String getNombre() { return nombre; }
    public String getTelefono() { return telefono; }

    public void actualizarDatos(String nombre, String telefono) {
        String nombreValidado = requerido(nombre, "El nombre");
        String telefonoValidado = requerido(telefono, "El teléfono");
        this.nombre = nombreValidado;
        this.telefono = telefonoValidado;
    }

    private static String requerido(String valor, String campo) {
        if (valor == null || valor.isBlank()) throw new IllegalArgumentException(campo + " no puede estar vacío.");
        return valor.trim();
    }

    @Override
    public String toString() { return identificacion + " - " + nombre + " (" + telefono + ")"; }
}
