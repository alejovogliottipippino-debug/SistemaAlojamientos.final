package com.alojamientos.algoritmos;

import com.alojamientos.modelo.Alojamiento;
import com.alojamientos.modelo.Habitacion;
import java.util.ArrayList;

/** Pruebas reproducibles de rendimiento y corrección, sin dependencias externas. */
public final class Benchmark {
    private static final int REPETICIONES = 5;
    private static final int CONSULTAS_POR_REPETICION = 100;
    private Benchmark() { }

    public static void ejecutar() {
        int[] tamanos = {150, 1_000, 10_000};
        System.out.println("\nBÚSQUEDAS (promedio en ns por consulta; 5 repeticiones de 100 consultas)");
        System.out.printf("%-10s %-12s %-16s %-16s%n", "Registros", "Caso", "Lineal", "Binaria");
        for (int n : tamanos) {
            ArrayList<Alojamiento> datos = generarDatos(n);
            String existente = String.format("ALO-%05d", n / 2);
            String inexistente = "NO-EXISTE";
            long linealExiste = medirBusqueda(datos, existente, false);
            long binariaExiste = medirBusqueda(datos, existente, true);
            long linealNoExiste = medirBusqueda(datos, inexistente, false);
            long binariaNoExiste = medirBusqueda(datos, inexistente, true);
            System.out.printf("%-10d %-12s %-16d %-16d%n", n, "existente", linealExiste, binariaExiste);
            System.out.printf("%-10d %-12s %-16d %-16d%n", n, "inexistente", linealNoExiste, binariaNoExiste);

            Alojamiento linealEncontrado = Busqueda.linealPorCodigo(datos, existente);
            Alojamiento binariaEncontrada = Busqueda.binariaPorCodigo(datos, existente);
            if (linealEncontrado == null || !linealEncontrado.getCodigo().equalsIgnoreCase(existente)
                    || binariaEncontrada == null || !binariaEncontrada.getCodigo().equalsIgnoreCase(existente)
                    || Busqueda.linealPorCodigo(datos, inexistente) != null
                    || Busqueda.binariaPorCodigo(datos, inexistente) != null)
                throw new IllegalStateException("La búsqueda no produjo el resultado esperado.");
        }

        System.out.println("\nORDENAMIENTOS (promedio en ns; copias preparadas antes de medir)");
        System.out.printf("%-10s %-16s %-16s%n", "Registros", "Selection Sort", "Merge Sort");
        for (int n : tamanos) {
            ArrayList<Alojamiento> original = generarDatos(n);
            long[] selection = medirOrdenamiento(original, false);
            long[] merge = medirOrdenamiento(original, true);
            System.out.printf("%-10d %-16d %-16d%n", n, promedio(selection), promedio(merge));
        }
        System.out.println("Verificación: las búsquedas y los dos ordenamientos devolvieron resultados correctos.");
    }

    private static long medirBusqueda(ArrayList<Alojamiento> datos, String codigo, boolean binaria) {
        long total = 0;
        int encontrados = 0;
        for (int r = 0; r < REPETICIONES; r++) {
            long inicio = System.nanoTime();
            for (int i = 0; i < CONSULTAS_POR_REPETICION; i++) {
                Alojamiento hallado = binaria ? Busqueda.binariaPorCodigo(datos, codigo)
                        : Busqueda.linealPorCodigo(datos, codigo);
                if (hallado != null) encontrados++;
            }
            total += System.nanoTime() - inicio;
        }
        int esperados = "NO-EXISTE".equals(codigo) ? 0 : REPETICIONES * CONSULTAS_POR_REPETICION;
        if (encontrados != esperados) throw new IllegalStateException("La búsqueda no produjo el resultado esperado.");
        return total / (REPETICIONES * CONSULTAS_POR_REPETICION);
    }

    private static long[] medirOrdenamiento(ArrayList<Alojamiento> original, boolean merge) {
        long[] tiempos = new long[REPETICIONES];
        for (int r = 0; r < REPETICIONES; r++) {
            ArrayList<Alojamiento> copia = new ArrayList<>(original); // fuera del tiempo medido
            long inicio = System.nanoTime();
            if (merge) Ordenamiento.mergeSort(copia);
            else Ordenamiento.selectionSort(copia);
            tiempos[r] = System.nanoTime() - inicio;
            verificarOrden(copia, original.size());
        }
        return tiempos;
    }

    private static ArrayList<Alojamiento> generarDatos(int cantidad) {
        ArrayList<Alojamiento> datos = new ArrayList<>();
        // Los códigos quedan en orden ascendente, condición necesaria para la búsqueda binaria.
        for (int i = 0; i < cantidad; i++) {
            double precio = 20 + ((i * 37) % 701);
            datos.add(new Habitacion(String.format("ALO-%05d", i), "Alojamiento " + i, 4, precio));
        }
        return datos;
    }

    private static void verificarOrden(ArrayList<Alojamiento> datos, int cantidadEsperada) {
        if (datos.size() != cantidadEsperada) throw new IllegalStateException("Se perdió un registro al ordenar.");
        for (int i = 1; i < datos.size(); i++)
            if (Ordenamiento.comparar(datos.get(i - 1), datos.get(i)) > 0)
                throw new IllegalStateException("El ordenamiento dejó elementos fuera de orden.");
    }

    private static long promedio(long[] datos) {
        long suma = 0;
        for (long dato : datos) suma += dato;
        return suma / datos.length;
    }
}
