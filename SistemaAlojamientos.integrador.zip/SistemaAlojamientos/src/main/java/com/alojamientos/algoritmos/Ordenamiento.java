package com.alojamientos.algoritmos;

import com.alojamientos.modelo.Alojamiento;
import java.util.ArrayList;

public final class Ordenamiento {
    private Ordenamiento() { }

    public static void selectionSort(ArrayList<Alojamiento> datos) {
        for (int i = 0; i < datos.size() - 1; i++) {
            int menor = i;
            for (int j = i + 1; j < datos.size(); j++)
                if (comparar(datos.get(j), datos.get(menor)) < 0) menor = j;
            if (menor != i) {
                Alojamiento temporal = datos.get(i);
                datos.set(i, datos.get(menor));
                datos.set(menor, temporal);
            }
        }
    }

    public static void mergeSort(ArrayList<Alojamiento> datos) {
        if (datos.size() < 2) return;
        ArrayList<Alojamiento> auxiliar = new ArrayList<>(datos);
        mergeSort(datos, auxiliar, 0, datos.size() - 1);
    }

    private static void mergeSort(ArrayList<Alojamiento> datos, ArrayList<Alojamiento> auxiliar, int inicio, int fin) {
        if (inicio >= fin) return;
        int medio = inicio + (fin - inicio) / 2;
        mergeSort(datos, auxiliar, inicio, medio);
        mergeSort(datos, auxiliar, medio + 1, fin);
        int i = inicio, j = medio + 1, k = inicio;
        while (i <= medio && j <= fin)
            auxiliar.set(k++, comparar(datos.get(i), datos.get(j)) <= 0 ? datos.get(i++) : datos.get(j++));
        while (i <= medio) auxiliar.set(k++, datos.get(i++));
        while (j <= fin) auxiliar.set(k++, datos.get(j++));
        for (k = inicio; k <= fin; k++) datos.set(k, auxiliar.get(k));
    }

    /** Precio ascendente; en empate, código ascendente. */
    public static int comparar(Alojamiento a, Alojamiento b) {
        int porPrecio = Double.compare(a.getPrecioPorNoche(), b.getPrecioPorNoche());
        if (porPrecio != 0) return porPrecio;
        return compararCodigos(a.getCodigo(), b.getCodigo());
    }

    private static int compararCodigos(String a, String b) {
        try {
            int numerico = Long.compare(Long.parseLong(a), Long.parseLong(b));
            return numerico != 0 ? numerico : a.compareToIgnoreCase(b);
        } catch (NumberFormatException ignored) {
            return a.compareToIgnoreCase(b);
        }
    }
}
