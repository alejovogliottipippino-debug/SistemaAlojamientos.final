package com.alojamientos.algoritmos;

import com.alojamientos.modelo.Alojamiento;
import java.util.ArrayList;

public final class Busqueda {
    private Busqueda() { }

    public static Alojamiento linealPorCodigo(ArrayList<Alojamiento> alojamientos, String codigo) {
        if (alojamientos == null || codigo == null) return null;
        for (Alojamiento alojamiento : alojamientos)
            if (alojamiento.getCodigo().equalsIgnoreCase(codigo)) return alojamiento;
        return null;
    }

    /** La colección recibida debe estar ordenada por código ascendente. */
    public static Alojamiento binariaPorCodigo(ArrayList<Alojamiento> ordenadosPorCodigo, String codigo) {
        if (ordenadosPorCodigo == null || codigo == null) return null;
        int izquierda = 0;
        int derecha = ordenadosPorCodigo.size() - 1;
        while (izquierda <= derecha) {
            int medio = izquierda + (derecha - izquierda) / 2;
            int comparacion = ordenadosPorCodigo.get(medio).getCodigo().compareToIgnoreCase(codigo);
            if (comparacion == 0) return ordenadosPorCodigo.get(medio);
            if (comparacion < 0) izquierda = medio + 1;
            else derecha = medio - 1;
        }
        return null;
    }
}
