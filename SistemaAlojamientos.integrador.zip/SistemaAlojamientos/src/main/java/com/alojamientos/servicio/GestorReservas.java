package com.alojamientos.servicio;

import com.alojamientos.algoritmos.Busqueda;
import com.alojamientos.algoritmos.Ordenamiento;
import com.alojamientos.modelo.*;
import java.time.LocalDate;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Properties;

public class GestorReservas {
    private static final Path ARCHIVO_ALOJAMIENTOS = Path.of("datos", "alojamientos.properties");
    private final ArrayList<Alojamiento> alojamientos = new ArrayList<>();
    private final ArrayList<Cliente> clientes = new ArrayList<>();
    private final ArrayList<Reserva> reservas = new ArrayList<>();
    private int siguienteReserva = 1;

    public GestorReservas() {
        cargarAlojamientos();
        cargarClientes();
    }

    public void registrarAlojamiento(Alojamiento alojamiento) {
        if (alojamiento == null) throw new IllegalArgumentException("El alojamiento es obligatorio.");
        if (buscarAlojamientoLineal(alojamiento.getCodigo()) != null)
            throw new IllegalArgumentException("Ya existe un alojamiento con ese código.");
        alojamientos.add(alojamiento);
        try { guardarAlojamientos(); }
        catch (IllegalStateException e) { alojamientos.remove(alojamiento); throw e; }
    }

    public void editarAlojamiento(Alojamiento actualizado) {
        if (actualizado == null) throw new IllegalArgumentException("El alojamiento es obligatorio.");
        int indice = -1;
        for (int i = 0; i < alojamientos.size(); i++)
            if (alojamientos.get(i).getCodigo().equalsIgnoreCase(actualizado.getCodigo())) { indice = i; break; }
        if (indice < 0) throw new IllegalArgumentException("No existe un alojamiento con ese código.");
        for (Reserva reserva : reservas)
            if (reserva.getEstado() == Reserva.Estado.ACTIVA
                    && reserva.getAlojamiento().getCodigo().equalsIgnoreCase(actualizado.getCodigo()))
                throw new IllegalStateException("No se puede editar: el alojamiento tiene una reserva activa.");

        Alojamiento anterior = alojamientos.set(indice, actualizado);
        try { guardarAlojamientos(); }
        catch (IllegalStateException e) { alojamientos.set(indice, anterior); throw e; }
    }

    public void registrarCliente(Cliente cliente) {
        if (cliente == null) throw new IllegalArgumentException("El cliente es obligatorio.");
        for (Cliente existente : clientes)
            if (mismaIdentificacion(existente.getIdentificacion(), cliente.getIdentificacion()))
                throw new IllegalArgumentException("Ya existe un cliente con esa identificación.");
        clientes.add(cliente);
        try { guardarAlojamientos(); }
        catch (IllegalStateException e) { clientes.remove(cliente); throw e; }
    }

    public void editarCliente(String identificacion, String nombre, String telefono) {
        Cliente cliente = buscarCliente(identificacion);
        if (cliente == null) throw new IllegalArgumentException("No existe un cliente con esa identificación.");
        String nombreAnterior = cliente.getNombre();
        String telefonoAnterior = cliente.getTelefono();
        cliente.actualizarDatos(nombre, telefono);
        try { guardarAlojamientos(); }
        catch (IllegalStateException e) {
            cliente.actualizarDatos(nombreAnterior, telefonoAnterior);
            throw e;
        }
    }

    public Reserva registrarReserva(String identificacionCliente, String codigoAlojamiento,
                                    LocalDate ingreso, LocalDate salida, int huespedes) {
        Cliente cliente = buscarCliente(identificacionCliente);
        if (cliente == null) throw new IllegalArgumentException("No existe un cliente con esa identificación.");
        Alojamiento alojamiento = buscarAlojamientoLineal(codigoAlojamiento);
        if (alojamiento == null) throw new IllegalArgumentException("No existe un alojamiento con ese código.");
        // La validación del constructor comprueba fechas y capacidad.
        String codigo = String.format("RES-%04d", siguienteReserva);
        Reserva nueva = new Reserva(codigo, cliente, alojamiento, ingreso, salida, huespedes);
        for (Reserva existente : reservas) {
            if (existente.getEstado() == Reserva.Estado.ACTIVA
                    && existente.getAlojamiento().getCodigo().equalsIgnoreCase(codigoAlojamiento)
                    && existente.seSuperpone(ingreso, salida))
                throw new IllegalArgumentException("El alojamiento ya tiene una reserva activa en esas fechas.");
        }
        reservas.add(nueva);
        siguienteReserva++;
        return nueva;
    }

    public void cancelarReserva(String codigo) {
        Reserva reserva = buscarReserva(codigo);
        if (reserva == null) throw new IllegalArgumentException("No existe una reserva con ese código.");
        reserva.cancelar();
    }

    public Cliente buscarCliente(String identificacion) {
        for (Cliente cliente : clientes)
            if (mismaIdentificacion(cliente.getIdentificacion(), identificacion)) return cliente;
        return null;
    }
    public String siguienteIdentificacionCliente() {
        long mayor = 0;
        for (Cliente cliente : clientes) {
            String id = normalizarIdentificacion(cliente.getIdentificacion());
            if (id.matches("\\d+")) {
                try { mayor = Math.max(mayor, Long.parseLong(id)); }
                catch (NumberFormatException ignored) { /* Se omiten identificadores numéricos demasiado grandes. */ }
            }
        }
        return String.valueOf(mayor + 1);
    }
    public Reserva buscarReserva(String codigo) {
        for (Reserva reserva : reservas) if (reserva.getCodigo().equalsIgnoreCase(codigo)) return reserva;
        return null;
    }
    public Alojamiento buscarAlojamientoLineal(String codigo) { return Busqueda.linealPorCodigo(alojamientos, codigo); }
    public Alojamiento buscarAlojamientoBinario(String codigo) {
        ArrayList<Alojamiento> copia = new ArrayList<>(alojamientos);
        // Ordenamiento manual por código, requisito previo para la búsqueda binaria.
        for (int i = 1; i < copia.size(); i++) {
            Alojamiento actual = copia.get(i);
            int j = i - 1;
            while (j >= 0 && copia.get(j).getCodigo().compareToIgnoreCase(actual.getCodigo()) > 0) {
                copia.set(j + 1, copia.get(j));
                j--;
            }
            copia.set(j + 1, actual);
        }
        return Busqueda.binariaPorCodigo(copia, codigo);
    }
    public ArrayList<Alojamiento> alojamientosOrdenadosPorPrecio(boolean usarMergeSort) {
        ArrayList<Alojamiento> copia = new ArrayList<>(alojamientos);
        if (usarMergeSort) Ordenamiento.mergeSort(copia);
        else Ordenamiento.selectionSort(copia);
        return copia;
    }

    public ArrayList<Alojamiento> alojamientosDisponibles(LocalDate ingreso, LocalDate salida) {
        if (ingreso == null || salida == null || !salida.isAfter(ingreso))
            throw new IllegalArgumentException("La fecha de salida debe ser posterior a la de ingreso.");
        ArrayList<Alojamiento> disponibles = new ArrayList<>();
        for (Alojamiento alojamiento : alojamientos) {
            boolean ocupado = false;
            for (Reserva reserva : reservas)
                if (reserva.getEstado() == Reserva.Estado.ACTIVA
                        && reserva.getAlojamiento().getCodigo().equalsIgnoreCase(alojamiento.getCodigo())
                        && reserva.seSuperpone(ingreso, salida)) {
                    ocupado = true;
                    break;
                }
            if (!ocupado) disponibles.add(alojamiento);
        }
        Ordenamiento.mergeSort(disponibles);
        return disponibles;
    }

    public ArrayList<Alojamiento> getAlojamientos() { return new ArrayList<>(alojamientos); }
    public ArrayList<Cliente> getClientes() { return new ArrayList<>(clientes); }
    public ArrayList<Reserva> getReservas() { return new ArrayList<>(reservas); }

    private void cargarAlojamientos() {
        if (!Files.exists(ARCHIVO_ALOJAMIENTOS)) {
            for (int i = 1; i <= 150; i++) {
                String codigo = String.valueOf(i);
                String nombre = String.format("Alojamiento %03d", i);
                int capacidad = 2 + i % 5;
                double precio = 20000 + (i % 20) * 2500;
                if (i % 5 == 0)
                    alojamientos.add(new Cabaña(codigo, nombre, capacidad, precio, 5000 + (i % 4) * 1500));
                else
                    alojamientos.add(new Habitacion(codigo, nombre, capacidad, precio));
            }
            guardarAlojamientos();
            return;
        }

        Properties datos = new Properties();
        try (Reader lector = Files.newBufferedReader(ARCHIVO_ALOJAMIENTOS, StandardCharsets.UTF_8)) {
            datos.load(lector);
            int cantidad = Integer.parseInt(datos.getProperty("cantidad", "0"));
            for (int i = 1; i <= cantidad; i++) {
                String prefijo = "alojamiento." + i + ".";
                String codigo = datoObligatorio(datos, prefijo + "codigo");
                String nombre = datoObligatorio(datos, prefijo + "nombre");
                int capacidad = Integer.parseInt(datoObligatorio(datos, prefijo + "capacidad"));
                double precio = Double.parseDouble(datoObligatorio(datos, prefijo + "precio"));
                String tipo = datoObligatorio(datos, prefijo + "tipo");
                if (tipo.equals("cabana")) {
                    double limpieza = Double.parseDouble(datoObligatorio(datos, prefijo + "limpieza"));
                    alojamientos.add(new Cabaña(codigo, nombre, capacidad, precio, limpieza));
                } else if (tipo.equals("habitacion")) {
                    alojamientos.add(new Habitacion(codigo, nombre, capacidad, precio));
                } else {
                    throw new IllegalArgumentException("Tipo desconocido en el registro " + codigo + ".");
                }
            }
        } catch (IOException | RuntimeException e) {
            throw new IllegalStateException("No se pudieron cargar los alojamientos de "
                    + ARCHIVO_ALOJAMIENTOS + ": " + e.getMessage(), e);
        }
    }

    private void cargarClientes() {
        Properties datos = new Properties();
        try (Reader lector = Files.newBufferedReader(ARCHIVO_ALOJAMIENTOS, StandardCharsets.UTF_8)) {
            datos.load(lector);
            int cantidad = Integer.parseInt(datos.getProperty("cantidadClientes", "0"));
            if (cantidad == 0) {
                for (int i = 1; i <= 150; i++)
                    clientes.add(new Cliente(identificadorDeEjemplo(i), String.format("Cliente de ejemplo %03d", i), "No informado"));
                guardarAlojamientos();
                return;
            }
            for (int i = 1; i <= cantidad; i++) {
                String prefijo = "cliente." + i + ".";
                clientes.add(new Cliente(datoObligatorio(datos, prefijo + "identificacion"),
                        datoObligatorio(datos, prefijo + "nombre"), datoObligatorio(datos, prefijo + "telefono")));
            }
        } catch (IOException | RuntimeException e) {
            throw new IllegalStateException("No se pudieron cargar los clientes de "
                    + ARCHIVO_ALOJAMIENTOS + ": " + e.getMessage(), e);
        }
    }

    private void guardarAlojamientos() {
        Properties datos = new Properties();
        datos.setProperty("cantidad", String.valueOf(alojamientos.size()));
        for (int i = 0; i < alojamientos.size(); i++) {
            Alojamiento alojamiento = alojamientos.get(i);
            String prefijo = "alojamiento." + (i + 1) + ".";
            datos.setProperty(prefijo + "codigo", alojamiento.getCodigo());
            datos.setProperty(prefijo + "nombre", alojamiento.getNombre());
            datos.setProperty(prefijo + "capacidad", String.valueOf(alojamiento.getCapacidad()));
            datos.setProperty(prefijo + "precio", String.valueOf(alojamiento.getPrecioPorNoche()));
            if (alojamiento instanceof Cabaña cabana) {
                datos.setProperty(prefijo + "tipo", "cabana");
                datos.setProperty(prefijo + "limpieza", String.valueOf(cabana.getCargoLimpieza()));
            } else {
                datos.setProperty(prefijo + "tipo", "habitacion");
            }
        }
        datos.setProperty("cantidadClientes", String.valueOf(clientes.size()));
        for (int i = 0; i < clientes.size(); i++) {
            Cliente cliente = clientes.get(i);
            String prefijo = "cliente." + (i + 1) + ".";
            datos.setProperty(prefijo + "identificacion", cliente.getIdentificacion());
            datos.setProperty(prefijo + "nombre", cliente.getNombre());
            datos.setProperty(prefijo + "telefono", cliente.getTelefono());
        }
        try {
            Files.createDirectories(ARCHIVO_ALOJAMIENTOS.getParent());
            try (Writer escritor = Files.newBufferedWriter(ARCHIVO_ALOJAMIENTOS, StandardCharsets.UTF_8)) {
                datos.store(escritor, "Alojamientos del SistemaAlojamientos");
            }
        } catch (IOException e) {
            throw new IllegalStateException("No se pudieron guardar los alojamientos: " + e.getMessage(), e);
        }
    }

    private static String datoObligatorio(Properties datos, String clave) {
        String valor = datos.getProperty(clave);
        if (valor == null) throw new IllegalArgumentException("Falta el dato " + clave + ".");
        return valor;
    }

    private static boolean mismaIdentificacion(String a, String b) {
        if (a == null || b == null) return false;
        return normalizarIdentificacion(a).equalsIgnoreCase(normalizarIdentificacion(b));
    }

    private static String normalizarIdentificacion(String identificacion) {
        String valor = identificacion.trim();
        if (valor.matches("\\d+")) {
            int inicio = 0;
            while (inicio < valor.length() - 1 && valor.charAt(inicio) == '0') inicio++;
            return valor.substring(inicio);
        }
        return valor;
    }

    private static String identificadorDeEjemplo(int numero) {
        return numero < 10 ? String.format("%02d", numero) : String.valueOf(numero);
    }
}
