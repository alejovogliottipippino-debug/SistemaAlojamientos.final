package com.alojamientos;

import com.alojamientos.algoritmos.Benchmark;
import com.alojamientos.modelo.*;
import com.alojamientos.servicio.GestorReservas;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {
    private static final Scanner ENTRADA = new Scanner(System.in);
    private static final GestorReservas GESTOR = new GestorReservas();

    public static void main(String[] args) {
        boolean continuar = true;
        while (continuar) {
            mostrarMenu();
            try {
                int opcion = leerEntero("Opción: ");
                switch (opcion) {
                    case 1 -> registrarHabitacion();
                    case 2 -> registrarCabaña();
                    case 3 -> registrarCliente();
                    case 4 -> registrarReserva();
                    case 5 -> consultarAlojamientos();
                    case 6 -> buscarAlojamiento(false);
                    case 7 -> buscarAlojamiento(true);
                    case 8 -> consultarDisponibles();
                    case 9 -> consultarReservas();
                    case 10 -> cancelarReserva();
                    case 11 -> Benchmark.ejecutar();
                    case 12 -> consultarCliente();
                    case 0 -> continuar = false;
                    default -> System.out.println("Seleccione una opción del menú.");
                }
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("No se pudo completar la operación: " + e.getMessage());
            } catch (NoSuchElementException e) {
                System.out.println("\nFin de la entrada. Programa finalizado.");
                break;
            }
        }
        System.out.println("Programa finalizado.");
    }

    private static void mostrarMenu() {
        System.out.println("\n=== Sistema de Alojamientos ===");
        System.out.println("1. Registrar habitación\n2. Registrar cabaña\n3. Registrar cliente\n4. Registrar reserva");
        System.out.println("5. Consultar alojamientos\n6. Buscar alojamiento por código (lineal)");
        System.out.println("7. Buscar alojamiento por código (binaria)\n8. Comparar disponibles por fecha y precio");
        System.out.println("9. Consultar reservas\n10. Cancelar reserva\n11. Ejecutar pruebas de rendimiento");
        System.out.println("12. Consultar cliente por identificador\n0. Salir");
    }

    private static void registrarHabitacion() {
        Habitacion habitacion = new Habitacion(leerTexto("Código: "), leerTexto("Nombre: "),
                leerEntero("Capacidad: "), leerDecimal("Precio por noche: "));
        GESTOR.registrarAlojamiento(habitacion);
        System.out.println("Habitación registrada:\n" + habitacion);
    }
    private static void registrarCabaña() {
        Cabaña cabana = new Cabaña(leerTexto("Código: "), leerTexto("Nombre: "),
                leerEntero("Capacidad: "), leerDecimal("Precio por noche: "), leerDecimal("Cargo de limpieza: "));
        GESTOR.registrarAlojamiento(cabana);
        System.out.println("Cabaña registrada:\n" + cabana);
    }
    private static void registrarCliente() {
        Cliente cliente = new Cliente(leerTexto("Identificador (sugerido: " + GESTOR.siguienteIdentificacionCliente() + "): "),
                leerTexto("Nombre: "), leerTexto("Teléfono: "));
        GESTOR.registrarCliente(cliente);
        System.out.println("Cliente registrado: " + cliente);
    }
    private static void registrarReserva() {
        String identificacion = leerTexto("Identificación del cliente: ");
        String codigo = leerTexto("Código del alojamiento: ");
        LocalDate ingreso = leerFecha("Fecha de ingreso (DD/MM/AAAA o DDMMAAAA): ");
        LocalDate salida = leerFecha("Fecha de salida (DD/MM/AAAA o DDMMAAAA): ");
        Reserva reserva = GESTOR.registrarReserva(identificacion, codigo, ingreso, salida, leerEntero("Cantidad de huéspedes: "));
        long noches = salida.toEpochDay() - ingreso.toEpochDay();
        System.out.println("Reserva registrada: " + reserva);
        System.out.printf("Costo estimado: $%.2f%n", reserva.getAlojamiento().calcularEstadia(noches));
    }
    private static void consultarAlojamientos() {
        ArrayList<Alojamiento> datos = GESTOR.getAlojamientos();
        if (datos.isEmpty()) { System.out.println("No hay alojamientos registrados."); return; }
        for (Alojamiento alojamiento : datos) System.out.println(alojamiento);
    }
    private static void buscarAlojamiento(boolean binaria) {
        String codigo = leerTexto("Código: ");
        Alojamiento hallado = binaria ? GESTOR.buscarAlojamientoBinario(codigo) : GESTOR.buscarAlojamientoLineal(codigo);
        if (hallado == null) {
            System.out.println("No se encontró el alojamiento.");
            return;
        }
        System.out.println(hallado);
        if (preguntarEdicion()) editarAlojamiento(hallado);
    }
    private static void consultarReservas() {
        ArrayList<Reserva> datos = GESTOR.getReservas();
        if (datos.isEmpty()) { System.out.println("No hay reservas registradas."); return; }
        for (Reserva reserva : datos) System.out.println(reserva);
    }
    private static void consultarCliente() {
        String identificacion = leerTexto("Identificador del cliente: ");
        Cliente cliente = GESTOR.buscarCliente(identificacion);
        if (cliente == null) {
            System.out.println("No se encontró un cliente con ese identificador.");
            return;
        }
        System.out.println("Datos del cliente: " + cliente);
        if (!preguntarEdicion()) return;
        String nombre = leerTexto("Nuevo nombre: ");
        String telefono = leerTexto("Nuevo teléfono: ");
        GESTOR.editarCliente(identificacion, nombre, telefono);
        System.out.println("Datos actualizados: " + cliente);
    }
    private static void consultarDisponibles() {
        LocalDate ingreso = leerFecha("Fecha de ingreso (DD/MM/AAAA o DDMMAAAA): ");
        LocalDate salida = leerFecha("Fecha de salida (DD/MM/AAAA o DDMMAAAA): ");
        ArrayList<Alojamiento> disponibles = GESTOR.alojamientosDisponibles(ingreso, salida);
        if (disponibles.isEmpty()) {
            System.out.println("No hay alojamientos disponibles para esas fechas.");
            return;
        }
        System.out.println("Disponibles ordenados por precio por noche (de menor a mayor):");
        for (int i = 0; i < disponibles.size(); i++) {
            if (i == 0) System.out.println("Menor precio por noche disponible:");
            System.out.println(disponibles.get(i));
        }
    }
    private static void editarAlojamiento(Alojamiento actual) {
        System.out.println("¿Qué datos querés cambiar? El código se conserva.");
        String nombre = leerTexto("Nuevo nombre: ");
        int capacidad = leerEntero("Nueva capacidad: ");
        double precio = leerDecimal("Nuevo precio por noche: ");
        Alojamiento actualizado;
        if (actual instanceof Cabaña cabaña) {
            double limpieza = leerDecimal("Nuevo cargo de limpieza: ");
            actualizado = new Cabaña(actual.getCodigo(), nombre, capacidad, precio, limpieza);
        } else {
            actualizado = new Habitacion(actual.getCodigo(), nombre, capacidad, precio);
        }
        GESTOR.editarAlojamiento(actualizado);
        System.out.println("Cambios guardados:\n" + actualizado);
    }
    private static boolean preguntarEdicion() {
        while (true) {
            int opcion = leerEntero("¿Querés editar? 1. Sí  2. No: ");
            if (opcion == 1) return true;
            if (opcion == 2) return false;
            System.out.println("Elegí 1 para sí o 2 para no.");
        }
    }
    private static void cancelarReserva() {
        GESTOR.cancelarReserva(leerTexto("Código de reserva: "));
        System.out.println("Reserva cancelada.");
    }

    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String valor = ENTRADA.nextLine().trim();
            if (!valor.isEmpty()) return valor;
            System.out.println("El valor no puede estar vacío.");
        }
    }
    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try { return Integer.parseInt(ENTRADA.nextLine().trim()); }
            catch (NumberFormatException e) { System.out.println("Ingrese un número entero válido."); }
        }
    }
    private static double leerDecimal(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String valor = ENTRADA.nextLine().trim().replace(',', '.');
            try {
                double numero = Double.parseDouble(valor);
                if (Double.isFinite(numero)) return numero;
            } catch (NumberFormatException ignored) { /* Se informa debajo. */ }
            System.out.println("Ingrese un número válido.");
        }
    }
    private static LocalDate leerFecha(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = ENTRADA.nextLine().trim();
            if (texto.matches("\\d{8}")) {
                texto = texto.substring(0, 2) + "/" + texto.substring(2, 4) + "/" + texto.substring(4);
            }
            DateTimeFormatter[] formatos = {
                    DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT),
                    DateTimeFormatter.ofPattern("dd-MM-uuuu").withResolverStyle(ResolverStyle.STRICT),
                    DateTimeFormatter.ISO_LOCAL_DATE
            };
            for (DateTimeFormatter formato : formatos) {
                try {
                    LocalDate fecha = LocalDate.parse(texto, formato);
                    System.out.println("Fecha ingresada: " + fecha.format(DateTimeFormatter.ofPattern("dd/MM/uuuu")));
                    return fecha;
                }
                catch (DateTimeParseException ignored) { /* Prueba el siguiente formato. */ }
            }
            System.out.println("Fecha inválida. Ingrese 8 números (DDMMAAAA) o use DD/MM/AAAA.");
        }
    }
}
