# SistemaAlojamientos

Aplicación de consola desarrollada en Java 17 para administrar alojamientos, clientes y reservas. Al primer inicio carga en segundo plano 150 alojamientos con códigos del 1 al 150 y 150 clientes ficticios de ejemplo. Sus datos quedan en `datos/alojamientos.properties`. La pantalla principal mantiene las opciones 1 a 12.

Trabajo Integrador Final de Programación II — Alejo Vogliotti.

## Funcionalidades

- Alta de habitaciones, cabañas y clientes, con códigos e identificaciones únicos.
- Consulta de alojamientos, clientes y reservas registrados durante la ejecución.
- Edición de nombre, capacidad y precio de los alojamientos; los cambios se guardan en un archivo local.
- Consulta por código con búsqueda lineal o binaria y opción para editar el alojamiento encontrado.
- Consulta de disponibilidad por fechas, ordenada por precio por noche.
- Consulta de cliente por identificador y opción para editar sus datos. Los ejemplos usan identificadores `01` a `09` y luego `10` a `150`; también se aceptan ceros iniciales al buscar. El siguiente identificador numérico sugerido es `151`.
- Alta y cancelación de reservas, control de capacidad y fechas, y prevención de superposiciones entre reservas activas.
- Cálculo del costo de estadía usando polimorfismo (las cabañas agregan limpieza).
- Búsqueda lineal y búsqueda binaria por código.
- Selection Sort y Merge Sort por precio ascendente y código ascendente en caso de empate.
- Benchmark reproducible de búsquedas y ordenamientos para 150, 1.000 y 10.000 registros.

## Requisitos

- JDK 17 o superior (`java -version` y `javac -version`).
- No se requieren frameworks, bases de datos ni dependencias externas.

## Compilar y ejecutar desde una terminal

Desde la carpeta raíz del proyecto:

```powershell
javac -encoding UTF-8 -d out (Get-ChildItem -Recurse src/main/java -Filter *.java | ForEach-Object { $_.FullName })
java '-Dfile.encoding=UTF-8' -cp out com.alojamientos.Main
```

En Linux o macOS se puede compilar con:

```bash
mkdir -p out
javac -encoding UTF-8 -d out $(find src/main/java -name '*.java')
java '-Dfile.encoding=UTF-8' -cp out com.alojamientos.Main
```

## Ejecutar desde VS Code

1. Abrir la carpeta `SistemaAlojamientos` en VS Code.
2. Instalar el Extension Pack for Java si VS Code lo solicita.
3. Abrir `src/main/java/com/alojamientos/Main.java` y elegir **Run** sobre el método `main`, o compilar y ejecutar desde la terminal integrada con los comandos anteriores.

Las fechas se pueden ingresar como `DD/MM/AAAA`, `DD-MM-AAAA`, `AAAA-MM-DD` o con ocho dígitos en formato `DDMMAAAA` (por ejemplo, `24112026`). La opción 8 pide el período y muestra los alojamientos disponibles de menor a mayor precio por noche. La opción 11 mide búsquedas y ordenamientos con 150, 1.000 y 10.000 registros. Los cambios de alojamientos y clientes se conservan en el archivo local; las reservas se reinician al salir. Ejecutá desde la carpeta raíz para que se use la carpeta `datos` del proyecto. El menú vuelve a aparecer después de cada operación.
