package com.alojamientos;

import com.alojamientos.algoritmos.Benchmark;
import com.alojamientos.modelo.*;
import com.alojamientos.servicio.GestorReservas;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {
    private static final Scanner ENTRADA = new Scanner(System.in);
    private static final GestorReservas GESTOR = new GestorReservas();

    public static void main(String[] args) {
        boolean continuar = true;
        while (continuar) {
            mostrarMenu();
            try {
                int opcion = leerEntero("Opción: ");
                switch (opcion) {
                    case 1 -> registrarHabitacion();
                    case 2 -> registrarCabaña();
                    case 3 -> registrarCliente();
                    case 4 -> registrarReserva();
                    case 5 -> consultarAlojamientos();
                    case 6 -> buscarAlojamiento(false);
                    case 7 -> buscarAlojamiento(true);
                    case 8 -> mostrarOrdenados();
                    case 9 -> consultarReservas();
                    case 10 -> cancelarReserva();
                    case 11 -> Benchmark.ejecutar();
                    case 0 -> continuar = false;
                    default -> System.out.println("Seleccione una opción del menú.");
                }
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println("No se pudo completar la operación: " + e.getMessage());
            } catch (NoSuchElementException e) {
                System.out.println("\nFin de la entrada. Programa finalizado.");
                break;
            }
        }
        System.out.println("Programa finalizado.");
    }

    private static void mostrarMenu() {
        System.out.println("\n=== Sistema de Alojamientos ===");
        System.out.println("1. Registrar habitación\n2. Registrar cabaña\n3. Registrar cliente\n4. Registrar reserva");
        System.out.println("5. Consultar alojamientos\n6. Buscar alojamiento por código (lineal)");
        System.out.println("7. Buscar alojamiento por código (binaria)\n8. Mostrar alojamientos ordenados por precio");
        System.out.println("9. Consultar reservas\n10. Cancelar reserva\n11. Ejecutar pruebas de rendimiento\n0. Salir");
    }

    private static void registrarHabitacion() {
        GESTOR.registrarAlojamiento(new Habitacion(leerTexto("Código: "), leerTexto("Nombre: "),
                leerEntero("Capacidad: "), leerDecimal("Precio por noche: ")));
        System.out.println("Habitación registrada.");
    }
    private static void registrarCabaña() {
        GESTOR.registrarAlojamiento(new Cabaña(leerTexto("Código: "), leerTexto("Nombre: "),
                leerEntero("Capacidad: "), leerDecimal("Precio por noche: "), leerDecimal("Cargo de limpieza: ")));
        System.out.println("Cabaña registrada.");
    }
    private static void registrarCliente() {
        GESTOR.registrarCliente(new Cliente(leerTexto("Identificación: "), leerTexto("Nombre: "), leerTexto("Teléfono: ")));
        System.out.println("Cliente registrado.");
    }
    private static void registrarReserva() {
        String identificacion = leerTexto("Identificación del cliente: ");
        String codigo = leerTexto("Código del alojamiento: ");
        LocalDate ingreso = leerFecha("Fecha de ingreso (AAAA-MM-DD): ");
        LocalDate salida = leerFecha("Fecha de salida (AAAA-MM-DD): ");
        Reserva reserva = GESTOR.registrarReserva(identificacion, codigo, ingreso, salida, leerEntero("Cantidad de huéspedes: "));
        long noches = salida.toEpochDay() - ingreso.toEpochDay();
        System.out.println("Reserva creada: " + reserva.getCodigo());
        System.out.printf("Costo estimado: $%.2f%n", reserva.getAlojamiento().calcularEstadia(noches));
    }
    private static void consultarAlojamientos() {
        ArrayList<Alojamiento> datos = GESTOR.getAlojamientos();
        if (datos.isEmpty()) { System.out.println("No hay alojamientos registrados."); return; }
        for (Alojamiento alojamiento : datos) System.out.println(alojamiento);
    }
    private static void buscarAlojamiento(boolean binaria) {
        String codigo = leerTexto("Código: ");
        Alojamiento hallado = binaria ? GESTOR.buscarAlojamientoBinario(codigo) : GESTOR.buscarAlojamientoLineal(codigo);
        System.out.println(hallado == null ? "No se encontró el alojamiento." : hallado);
    }
    private static void mostrarOrdenados() {
        for (Alojamiento alojamiento : GESTOR.alojamientosOrdenadosPorPrecio(true)) System.out.println(alojamiento);
    }
    private static void consultarReservas() {
        ArrayList<Reserva> datos = GESTOR.getReservas();
        if (datos.isEmpty()) { System.out.println("No hay reservas registradas."); return; }
        for (Reserva reserva : datos) System.out.println(reserva);
    }
    private static void cancelarReserva() {
        GESTOR.cancelarReserva(leerTexto("Código de reserva: "));
        System.out.println("Reserva cancelada.");
    }

    private static String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String valor = ENTRADA.nextLine().trim();
            if (!valor.isEmpty()) return valor;
            System.out.println("El valor no puede estar vacío.");
        }
    }
    private static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try { return Integer.parseInt(ENTRADA.nextLine().trim()); }
            catch (NumberFormatException e) { System.out.println("Ingrese un número entero válido."); }
        }
    }
    private static double leerDecimal(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String valor = ENTRADA.nextLine().trim().replace(',', '.');
            try {
                double numero = Double.parseDouble(valor);
                if (Double.isFinite(numero)) return numero;
            } catch (NumberFormatException ignored) { /* Se informa debajo. */ }
            System.out.println("Ingrese un número válido.");
        }
    }
    private static LocalDate leerFecha(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try { return LocalDate.parse(ENTRADA.nextLine().trim()); }
            catch (DateTimeParseException e) { System.out.println("Fecha inválida. Use el formato AAAA-MM-DD."); }
        }
    }
}
