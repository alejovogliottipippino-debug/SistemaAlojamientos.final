package com.alojamientos.modelo;

public class Cliente {
    private final String identificacion;
    private final String nombre;
    private final String telefono;

    public Cliente(String identificacion, String nombre, String telefono) {
        this.identificacion = requerido(identificacion, "La identificación");
        this.nombre = requerido(nombre, "El nombre");
        this.telefono = requerido(telefono, "El teléfono");
    }

    public String getIdentificacion() { return identificacion; }
    public String getNombre() { return nombre; }
    public String getTelefono() { return telefono; }

    private static String requerido(String valor, String campo) {
        if (valor == null || valor.isBlank()) throw new IllegalArgumentException(campo + " no puede estar vacío.");
        return valor.trim();
    }

    @Override
    public String toString() { return identificacion + " - " + nombre + " (" + telefono + ")"; }
}
