package com.alojamientos.modelo;

/** Representa un alojamiento que puede ofrecerse para una estadía. */
public abstract class Alojamiento {
    private final String codigo;
    private final String nombre;
    private final String tipo;
    private final int capacidad;
    private final double precioPorNoche;

    protected Alojamiento(String codigo, String nombre, String tipo, int capacidad, double precioPorNoche) {
        this.codigo = textoObligatorio(codigo, "El código");
        this.nombre = textoObligatorio(nombre, "El nombre");
        this.tipo = textoObligatorio(tipo, "El tipo");
        if (capacidad <= 0) throw new IllegalArgumentException("La capacidad debe ser mayor que cero.");
        this.capacidad = capacidad;
        if (!Double.isFinite(precioPorNoche) || precioPorNoche <= 0)
            throw new IllegalArgumentException("El precio debe ser un número mayor que cero.");
        this.precioPorNoche = precioPorNoche;
    }

    public abstract double calcularEstadia(long noches);

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public String getTipo() { return tipo; }
    public int getCapacidad() { return capacidad; }
    public double getPrecioPorNoche() { return precioPorNoche; }

    protected static String textoObligatorio(String valor, String campo) {
        if (valor == null || valor.isBlank()) throw new IllegalArgumentException(campo + " no puede estar vacío.");
        return valor.trim();
    }

    @Override
    public String toString() {
        return String.format("%-10s %-20s %-12s capacidad: %-3d precio/noche: $%.2f",
                codigo, nombre, tipo, capacidad, precioPorNoche);
    }
}
