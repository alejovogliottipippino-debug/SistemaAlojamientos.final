package com.alojamientos.servicio;

import com.alojamientos.algoritmos.Busqueda;
import com.alojamientos.algoritmos.Ordenamiento;
import com.alojamientos.modelo.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class GestorReservas {
    private final ArrayList<Alojamiento> alojamientos = new ArrayList<>();
    private final ArrayList<Cliente> clientes = new ArrayList<>();
    private final ArrayList<Reserva> reservas = new ArrayList<>();
    private int siguienteReserva = 1;

    public void registrarAlojamiento(Alojamiento alojamiento) {
        if (alojamiento == null) throw new IllegalArgumentException("El alojamiento es obligatorio.");
        if (buscarAlojamientoLineal(alojamiento.getCodigo()) != null)
            throw new IllegalArgumentException("Ya existe un alojamiento con ese código.");
        alojamientos.add(alojamiento);
    }

    public void registrarCliente(Cliente cliente) {
        if (cliente == null) throw new IllegalArgumentException("El cliente es obligatorio.");
        for (Cliente existente : clientes)
            if (existente.getIdentificacion().equalsIgnoreCase(cliente.getIdentificacion()))
                throw new IllegalArgumentException("Ya existe un cliente con esa identificación.");
        clientes.add(cliente);
    }

    public Reserva registrarReserva(String identificacionCliente, String codigoAlojamiento,
                                    LocalDate ingreso, LocalDate salida, int huespedes) {
        Cliente cliente = buscarCliente(identificacionCliente);
        if (cliente == null) throw new IllegalArgumentException("No existe un cliente con esa identificación.");
        Alojamiento alojamiento = buscarAlojamientoLineal(codigoAlojamiento);
        if (alojamiento == null) throw new IllegalArgumentException("No existe un alojamiento con ese código.");
        // La validación del constructor comprueba fechas y capacidad.
        String codigo = String.format("RES-%04d", siguienteReserva);
        Reserva nueva = new Reserva(codigo, cliente, alojamiento, ingreso, salida, huespedes);
        for (Reserva existente : reservas) {
            if (existente.getEstado() == Reserva.Estado.ACTIVA
                    && existente.getAlojamiento().getCodigo().equalsIgnoreCase(codigoAlojamiento)
                    && existente.seSuperpone(ingreso, salida))
                throw new IllegalArgumentException("El alojamiento ya tiene una reserva activa en esas fechas.");
        }
        reservas.add(nueva);
        siguienteReserva++;
        return nueva;
    }

    public void cancelarReserva(String codigo) {
        Reserva reserva = buscarReserva(codigo);
        if (reserva == null) throw new IllegalArgumentException("No existe una reserva con ese código.");
        reserva.cancelar();
    }

    public Cliente buscarCliente(String identificacion) {
        for (Cliente cliente : clientes)
            if (cliente.getIdentificacion().equalsIgnoreCase(identificacion)) return cliente;
        return null;
    }
    public Reserva buscarReserva(String codigo) {
        for (Reserva reserva : reservas) if (reserva.getCodigo().equalsIgnoreCase(codigo)) return reserva;
        return null;
    }
    public Alojamiento buscarAlojamientoLineal(String codigo) { return Busqueda.linealPorCodigo(alojamientos, codigo); }
    public Alojamiento buscarAlojamientoBinario(String codigo) {
        ArrayList<Alojamiento> copia = new ArrayList<>(alojamientos);
        // Ordenamiento manual por código, requisito previo para la búsqueda binaria.
        for (int i = 1; i < copia.size(); i++) {
            Alojamiento actual = copia.get(i);
            int j = i - 1;
            while (j >= 0 && copia.get(j).getCodigo().compareToIgnoreCase(actual.getCodigo()) > 0) {
                copia.set(j + 1, copia.get(j));
                j--;
            }
            copia.set(j + 1, actual);
        }
        return Busqueda.binariaPorCodigo(copia, codigo);
    }
    public ArrayList<Alojamiento> alojamientosOrdenadosPorPrecio(boolean usarMergeSort) {
        ArrayList<Alojamiento> copia = new ArrayList<>(alojamientos);
        if (usarMergeSort) Ordenamiento.mergeSort(copia);
        else Ordenamiento.selectionSort(copia);
        return copia;
    }

    public ArrayList<Alojamiento> getAlojamientos() { return new ArrayList<>(alojamientos); }
    public ArrayList<Cliente> getClientes() { return new ArrayList<>(clientes); }
    public ArrayList<Reserva> getReservas() { return new ArrayList<>(reservas); }
}
